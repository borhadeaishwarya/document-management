package com.document.security;

import java.io.IOException;
import java.security.Security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.web.authentication.WebAuthenticationDetails;
import org.springframework.security.web.authentication.WebAuthenticationDetailsSource;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;


//it checks token in request,validate extract username,per request run 
@Component
public class JwtFilter extends OncePerRequestFilter {
	
  @Autowired
	private JwtSecure jwtSecure;
  @Autowired
     private UserDetailsService userDetailsService; 
	@Override
	protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain)
			throws ServletException, IOException {
		
		//skip jwt filter for this endpoints
	String path = request.getRequestURI();
	if(path.startsWith("/auth")||path.startsWith("/api/document/welcome")) {
		filterChain.doFilter(request, response);
		return;
	}
		
		
		String header = request.getHeader("Authorization");
		String token=null;
		String username=null;
		
	    System.out.println("URI = " + request.getRequestURI());
	    System.out.println("HEADER = " + header);
	     	
		if(header!=null && header.startsWith("Bearer ")) {
			token=header.substring(7);
	        System.out.println("TOKEN = " + token);  // Debug

			try {
			username=jwtSecure.extractUsername(token);
			System.out.println("USERNAME="+username );
			}
			catch(Exception e){
				System.out.println("Token error=" +e.getMessage());
				
			}
		}
		if(username!=null && SecurityContextHolder.getContext().getAuthentication()==null)
		{
			if(jwtSecure.validateToken(token)) {
				
				UserDetails userDetails = userDetailsService.loadUserByUsername(username);
				UsernamePasswordAuthenticationToken authToken = new UsernamePasswordAuthenticationToken(userDetails,null,userDetails.getAuthorities());
			
				authToken.setDetails(new WebAuthenticationDetailsSource().buildDetails(request));
				
				SecurityContextHolder.getContext().setAuthentication(authToken);
			}
		}
	filterChain.doFilter(request,response);
	}
}

